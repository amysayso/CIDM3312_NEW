namespace ConverterLib.Mass
{
    public interface IMassConversions

    {
        string GetMass(decimal massIn);    
    }
}