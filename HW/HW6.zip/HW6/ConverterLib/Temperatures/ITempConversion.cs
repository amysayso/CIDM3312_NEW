namespace ConverterLib.Temperatures
{
    public interface ITempConversions
    {
        string Temp(decimal tempIn);
    }
}