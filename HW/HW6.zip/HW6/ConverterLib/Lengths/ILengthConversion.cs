namespace ConverterLib.Lengths
{
    public interface ILengthConversions
    {
        decimal Lengths(decimal LengthIn);
    }
}