#buffteks homework
#Creating and Reading data 